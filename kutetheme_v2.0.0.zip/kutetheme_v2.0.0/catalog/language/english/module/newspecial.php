<?php
// Heading
$_['heading_title'] = 'Last deal';

// Text
$_['text_tax']      = 'Ex Tax:';