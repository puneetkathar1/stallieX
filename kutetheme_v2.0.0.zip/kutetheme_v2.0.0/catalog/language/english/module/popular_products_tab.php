<?php
$_['tab_ppp_most_viewed']  = 'Most Viewed';
$_['tab_ppp_best_seller']  = 'Best Seller';
$_['tab_ppp_most_reviews'] = 'Most Reviews';
$_['tab_ppp_new_arrivals'] = 'New Products';
$_['tab_ppp_featured']     = 'Featured Products';
$_['tab_ppp_special']      = 'On Sale';