<?php
$_['tab_most_viewed']  = 'Most Viewed';
$_['tab_best_seller']  = 'Best Seller';
$_['tab_most_reviews'] = 'Most Reviews';
$_['tab_new_arrivals'] = 'New Arrivals';
$_['tab_special']      = 'Special';