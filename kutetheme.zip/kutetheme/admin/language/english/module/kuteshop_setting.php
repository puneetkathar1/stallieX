<?php
// Heading
$_['heading_title']    = '<b style="color: green;font-size:15px">Kuteshop Setting<b/>';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified carousel module!';
$_['text_edit']        = 'Edit Carousel Module';
