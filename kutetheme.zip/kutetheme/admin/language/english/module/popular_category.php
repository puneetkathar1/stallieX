<?php
// Heading
$_['heading_title']    = 'Popular Category';

$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified account module!';
$_['text_edit']        = 'Edit Account Module';

// Entry
$_['entry_name']       = 'Module Name';
$_['entry_category_1']     = 'Category 1st';
$_['entry_category_2']     = 'Category 2nd';
$_['entry_category_3']     = 'Category 3rd';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify account module!';