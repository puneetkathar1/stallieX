<?php

// Heading 
$_['heading_title']      	= 'Simple Blog';

$_['text_date_format']		= 'F jS, Y';

$_['text_popular_all']		= 'Popular Articles';
$_['text_latest_all']		= 'Latest Articles';

$_['text_no_result']		= 'No Result!';

?>