<?php
/**
 * Created by ANH To <anh.to87@gmail.com>.
 * User: baoan
 * Date: 10/10/15
 * Time: 22:36
 */

$_['text_title'] = 'Filter selection';
$_['text_by_category'] = 'Category';
$_['text_by_price'] = 'Price';
$_['text_by_brand'] = 'Brand';
$_['text_by_size'] = 'Size';